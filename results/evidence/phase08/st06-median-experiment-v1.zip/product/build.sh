#!/bin/bash
set -eu
cd /tmp/st06-median-product
base=/home/emirhan/projects/electronic-warfare-zedboard/build/tmp/work/zynq_generic_7z020-amd-linux-gnueabi/p0-dma/1.0
"$base/recipe-sysroot-native/usr/bin/arm-amd-linux-gnueabi/arm-amd-linux-gnueabi-gcc" -std=c11 -O3 -Wall -Wextra -Werror -pedantic -mthumb -mfpu=neon -mfloat-abi=hard -mcpu=cortex-a9 -fstack-protector-strong -D_FORTIFY_SOURCE=2 -D_TIME_BITS=64 -D_FILE_OFFSET_BITS=64 --sysroot="$base/recipe-sysroot" -I. p0_dma_runtime.c p0_parameter_runtime.c p0_ed_pipeline.c p0_ed_service_protocol.c p0_ed_service.c p0_os_cfar.c p0_pl_os_cfar.c p0_multiscale_detector.c p0_candidate_packet.c p0_persistent_weak.c p0_st05_wideband.c p0_st05_stream.c phase06j_temporal.c -lm -pthread -o p0-ed-service-median
