import hashlib
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from app.operator_console.measurement_record import json_bytes, runtime_binding, replay_measurement
from scripts.verify_phase04f5_product_integration import build_summary

OUT = Path(__file__).resolve().parent
DEST = ROOT / 'results/evidence/phase08/parameter-workflow-v1.json'
suite = ET.parse(OUT / 'tests.xml').getroot().find('testsuite')
assert int(suite.attrib['failures']) == 0 and int(suite.attrib['errors']) == 0
assert int(suite.attrib['tests']) == 137
ui_suite = ET.parse(OUT / 'ui-final-tests.xml').getroot().find('testsuite')
assert int(ui_suite.attrib['tests']) == 30 and int(ui_suite.attrib['failures']) == 0 and int(ui_suite.attrib['errors']) == 0
sample = json.loads((OUT / 'sample-summary.json').read_text(encoding='utf-8'))
replay_measurement(OUT / sample['archive'], expected_sha256=sample['sha256'])
binding = runtime_binding()
summary = json.loads((OUT / 'f5-current-integration.json').read_text(encoding='utf-8'))
assert summary == build_summary() and summary['status'] == 'passed'
previous = json.loads((ROOT / 'results/evidence/phase08/parameter-record-v1.json').read_text(encoding='utf-8'))
previous_bytes = (ROOT / 'results/evidence/phase08/parameter-record-v1.zip').read_bytes()
assert hashlib.sha256(previous_bytes).hexdigest() == previous['archive_sha256']
with zipfile.ZipFile(ROOT / 'results/evidence/phase08/parameter-record-v1.zip') as old:
    assert all(hashlib.sha256(old.read(name)).hexdigest() == value for name, value in previous['entry_sha256'].items())
paths = set(binding['sources_sha256']) | {
    'app/operator_console/qml/Main.qml', 'app/operator_console/qml/ParameterMeasurementPanel.qml',
    'app/operator_console/qml/RxSurveyView.qml', 'app/operator_console/quick_scan_actions.py',
    'scripts/verify_parameter_record.py', 'scripts/verify_phase04f5_product_integration.py',
    'tests/test_measurement_record.py', 'tests/test_live_ed_view_model.py',
    'tests/test_live_ed_session.py', 'tests/test_phase04f5_product_profile.py',
    'tests/test_app_f_quick_product.py', 'tests/test_operator_product_boundary.py',
    'tests/test_repository_contract.py', 'tests/test_architecture_boundaries.py',
    'config/app/product-package.json', 'app/operator_console/pysidedeploy.spec',
    'scripts/verify_phase00.py', 'profiles/phase04f5/operation-default.json',
    'README.md', 'app/README.md', 'algorithms/README.md', 'platforms/embedded/README.md',
    'docs/plans/IMPLEMENTATION_ROADMAP.md', 'docs/architecture/P0_SYSTEM_ARCHITECTURE.md',
    'docs/interfaces/OPERATOR_ASSISTED_PARAMETER_CONTRACT.md',
    'docs/interfaces/SIGNAL_DETECTION_STATUS.md', 'docs/requirements/KTR_TRACEABILITY.md',
}
entries = {f'sources/{name}': (ROOT / name).read_bytes() for name in sorted(paths)}
for path in sorted(OUT.iterdir()):
    if path.suffix in {'.py', '.json', '.txt', '.xml', '.png'} or path.name == 'sample-record.zip':
        entries[path.name] = path.read_bytes()
archive = DEST.with_suffix('.zip')
assert not DEST.exists() and not archive.exists(), 'Existing evidence must not be replaced'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as target:
    for name, data in entries.items():
        target.writestr(name, data)
report = {
    'schema': 'parameter-workflow-acceptance-v1', 'date': '2026-09-07',
    'status': 'software_workflow_verified', 'overall_test_suite_status': 'passed',
    'requirements': ['KTR-4.2', 'KTR-4.2-F1'], 'work_item': 'PÇ-01',
    'physical_rf_test': False, 'new_board_test': False, 'accuracy_proven': False,
    'tests': {'total': 137, 'passed': 137, 'failed': 0, 'errors': 0},
    'final_ui_recheck': {'total': 30, 'passed': 30, 'reason': 'Scroll bar placement adjusted after the full suite; affected QML and architecture suite rerun.'},
    'test_command': 'python -m pytest -q tests/test_measurement_record.py tests/test_live_ed_session.py tests/test_live_ed_view_model.py tests/test_phase04f5_product_profile.py tests/test_app_f_quick_product.py tests/test_operator_product_boundary.py tests/test_repository_contract.py tests/test_architecture_boundaries.py',
    'checks': ['four primary fields and expandable details', 'invalid range revokes approval',
        'Turkish decimal input through QML button', 'missing event and sequence gap revoke current window',
        'latest window replaces selection cache as input', 'reacquisition clears selection and results',
        'repeat measurement creates new record', 'cancel during RX stop and worker rejects late result',
        'mixed receiver context and record write failure reject result', 'record replay matches every field'],
    'visual_qa': {'sizes': [[1280,720],[1920,1080]], 'states': ['empty','approved-range','recorded-result','details'],
        'backend': 'Qt offscreen software', 'source': 'datasets/fixtures/phase01/known-tone-ci8.sigmf-meta',
        'manual_review': 'Four required fields fit at both sizes; details scroll at 720p; no overlapping main controls.'},
    'architecture_lines': {name: len((ROOT / name).read_text(encoding='utf-8').splitlines()) for name in
        ['app/operator_console/qml/Main.qml', 'app/operator_console/quick_view_model.py']},
    'sample_record_sha256': sample['sha256'], 'sample_replay': 'passed',
    'current_f5_integration': summary['status'], 'previous_record_evidence_integrity': 'passed',
    'archive': archive.name, 'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'entry_sha256': {name: hashlib.sha256(data).hexdigest() for name, data in entries.items()},
    'runtime': binding,
    'limits': ['Software workflow acceptance only; no RF accuracy or new board acceptance.',
        'dBFS remains uncalibrated; dBm, ARM migration and ST-06 remain open.',
        'A cancelled worker may finish a local record; its result is not published.',
        'Receiver settings are session configuration, not independent device readback.',
        'Four observations are current relative to the last processed response, not a hardware UTC age bound.',
        'The fixed known-tone fixture is for workflow checks, not bandwidth/SNR/classification accuracy.'],
}
DEST.write_bytes(json_bytes(report))
print(json.dumps({'status': report['status'], 'tests': report['tests'], 'archive_bytes': archive.stat().st_size}))
