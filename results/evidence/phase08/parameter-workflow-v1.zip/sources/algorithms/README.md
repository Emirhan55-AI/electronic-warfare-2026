# Referans Modeller

## PÇ-01 sınırı — 7 Eylül 2026

KTR-4.2 / KTR-4.2-F1 arayüz ve güncel gözlem bağı uygulanmıştır.
Kestirimci, RTL ve kart hizmeti değişmedi; F5 ölçümü bilgisayarda kalır.
Yazılım kanıtı `results/evidence/phase08/parameter-workflow-v1.json` ve ZIP;
RF doğruluğu, dBm kalibrasyonu ve ARM taşıması bu kabulün dışındadır.

## PÇ-00 yeniden üretilebilir ölçüm bağı — 7 Eylül 2026

KTR-4.2 için uygulama katmanı F5'e verilen dört normalize I/Q karesini,
profil/model/kaynak özetlerini ve ham alan durumlarını saklar. Aynı kaynakla
`scripts/verify_parameter_record.py` alanları yeniden hesaplar; uyumsuz
kaynak, değişmiş I/Q veya sonuç reddedilir. F5/RTL/ARM algoritması, eşikleri
ve kilitli profilleri değiştirilmedi. Bu kayıt eşdeğerliğidir, bağımsız RF
doğruluğu değildir. Yeni kanıt `results/evidence/phase08/parameter-record-v1.json`
ve ZIP içindedir; PÇ-02 fiziksel doğruluk ve kalibrasyon kapıları açıktır.

## Zorunlu parametrelerin mevcut yöntemi — 7 Eylül 2026

Kullanıcı dört zorunlu alanın geliştirme planlamasını açtı. QML ürün yolu
`parameters/F5ParameterEstimator` kullanır; ayrı `p0/parameters.py` referansı
ile karıştırılmaz. F5 taşıyıcı çizgisi, OBW99, göreli kanal gücü ve sınırlı
Analog/Sayısal/Belirsiz alanlarını içerir. ARM C sayısal karşılaştırması bu
oturumda AM/geniş bantta sıfır farkla geçti; bu host testi yeni RF kanıtı
değildir. OBW99 yöntem sınırı, kalibrasyon, sınıflandırma ve ARM taşıma sırası
[yol haritasındadır](../docs/plans/IMPLEMENTATION_ROADMAP.md). Yöntem, eşik ve
kilitli profiller değiştirilmedi; ST-06 ve parametre RF kabulü açıktır.

## Son ST-06 ürün güncellemesi — 5 Eylül 2026

Paketlenmiş hizmette CPU0 DMA sonrası güç çözme/doğrulamayı, CPU1 dar/geniş
aday ve olay işlerini yürütür. Kuyruk tamponlarının sahipliği değiştirilerek
ek kopya önlenir; hata geri alımında ortalama kayıtlı toplamdan türetilir.
Algoritma, medyan, eşikler ve RTL değişmedi. Üç zaman damgalı dijital ürün
koşusu 508,56 / 502,40 / 508,93 kare/s; 16.000 karelik karma tekrar ölçümü
529,30 kare/s verdi. Gerekli 488,28125 kare/s bu iş yüklerinde sağlandı.
Beş kısa testin ham yanıtları önceki paketle birebir eşleşti. Aktarım hatası
ve aday düşümü sıfırdı. Ek ARM kuyruk belleği 272 KiB'dir; FPGA artışı yoktur.
Kanıt: `results/evidence/phase08/st06-parallel-product-v1.json` ve ZIP.
Bu sonuç RF veya soğuk açılış kabulü değildir. SD değişmedi, hizmet geçici
yüklüdür. Hız payı sınırlıdır; saf periyodik ton/yoğun olay kapasitesi,
sürekli HackRF RX ve kör RF kapıları açıktır. ST-06 tamamlanmamıştır.
Aşağıdaki eski hız kayıtları kendi kaynak sürümlerinin tarihsel sonuçlarıdır.


5 Eylül 2026 son ST-06 optimizasyonu: ARM güç çözme ve durum yedekleme
maliyeti azaltıldı; eşikler, sekiz karelik pencere ve RTL değişmedi. PetaLinux
paketinden çıkan hizmetle üç fiziksel dijital koşu 464,87 / 460,37 / 463,74
kare/s verdi. Önceki 286–290 kare/s kaydı tarihsel karşılaştırmadır;
488,28125 kare/s kabul sınırı hâlâ geçilemedi. Beş test girdisinin kart
yanıtları önceki sürümle byte-tam eşleşti. Bu, RF doğruluk kabulü değildir.
Kanıt: `results/evidence/phase08/st06-product-optimization-v1.json` ve ZIP.
SD açılış dosyaları değişmedi; güncel hizmet geçici yüklüdür. ST-06 sürer.

Önceki kayıtlar ve mimari açıklamalar:

Güncel PHASE-08/ST-06 sinyal tespiti için `p0/st05_wideband.py` geniş bant
referansıdır; C eşdeğeri ZedBoard ARM'de çalışır. Hann/FFT/güç/OS-CFAR hücre
kararı PL'dedir. Dijital kart tanısı ürün hızını henüz geçememiştir.
[Güncel durum](../docs/interfaces/SIGNAL_DETECTION_STATUS.md) kaynak/kanıt
sınırını tanımlar. Aşağıdaki faz açıklamaları ilgili tarihsel sürümlerin
özetidir; örneğin E1'in başarısızlığı daha sonraki F5 host profilinin sonucu
olarak okunmaz. Parametre/DF/ET bu ST-06 çalışmasının kapsamı değildir.

- `sigmf/`, PHASE-01 metadata ve binary yerleşim sözleşmesini yalnız Python standart kütüphanesiyle doğrular. Örnek değerlerini dönüştürmez ve DSP uygulamaz.
- `spectrum/`, PHASE-02 bounded SigMF çerçeve kaynağını ve Qt'den bağımsız floating-point Hann/FFT/güç/PSD golden modelini içerir.
- `detection/`, PHASE-03 bölgesel/CA/OS detectorlerini, kaba bölge gruplamasını, bounded temporal olay belleğini ve katalog tabanlı sentetik sahneleri içerir.
- `pipeline/`, allowlist bloklarından doğrulanmış işlem profilini kurar; PHASE-04 ve E1 alan-bazlı comparison/digest bağlarını doğrular ve geçersiz bağda PHASE-03 Operasyon zincirine döner.
- `parameters/`, PHASE-04 geçerlilik modeli ve başarısızlık deneylerinin yanında E1 confirmed-olay span önerisini, dört bounded frame ölçümünü, taşıyıcı çizgisi/emisyon merkezi/OBW99/dBFS/sınırlı alan kurallarını ve `34.084 byte` kalıcı payload sınırını içerir. E1 profili yalnız doğrulanan alanları kurabilir; mevcut karşılaştırmada doğrulanan alan yoktur.
- `monitoring/`, operatör seçimli AM/NFM için bounded DDC, FIR kanal süzme, frame-sürekli NFM faz farkı, 48 kHz mono ses, PCM16/WAV ve deterministik fixture/evaluation sözleşmesini içerir.
- `rtl/`, PHASE-06A `ci8` AXI4-Stream frame-istatistik bloğunun yalnız tam sayı kullanan bit-doğru Python golden modelini ve deterministik HDL vektör üretimini içerir.
- `rtl/hann_window.py` ve `rtl/hann_vectors.py`, PHASE-02 float64 periyodik Hann dizisinden dondurulmuş UQ1.15 katsayı üretir; donanım sonucunu integer çarpım, açık yuvarlama ve SQ1.15 çıkışla bit-doğru modeller.
- `rtl/fft_model.py` ve `rtl/fft_vectors.py`, PHASE-06C için PHASE-02 unscaled forward FFT'yi SQ1.15 giriş/29-bit Q15 çıkış sınırında idealize eder, scaling adaylarını nicel karşılaştırır ve wrapper transport stub vektörünü matematiksel FFT golden'ından ayrı tutar.

PHASE-06C Python modeli seçilen dış FFT sayısal sözleşmesini karakterize eder fakat AMD C-model değildir. Gerçek vendor FFT sonucu PHASE-06D'nin ayrı AMD C-model/XSim katmanında doğrulanır; FFT sonrası güç ve detector PL biçimi uygulanmamıştır. PHASE-04 sonuçları yalnız katalogdaki sentetik ailelerde ve kayıtlı I/Q çalışma yolunda doğrulanabilir; genel gerçek dünya sınıflandırması, kalibre edilmiş RF gücü veya canlı RF işlevi değildir.

`algorithms/fpga/phase06d_vectors.py`, PHASE-06C'nin on giriş frame'ini byte-değişmez devralır ve natural-order negatif frekans denetimi için exact-bin tone ekler. `rtl/amd_xfft_cmodel_driver.cpp`, yerel AMD FFT v9.1 bit-accurate C-model API'sini dondurulmuş fixed-point yapılandırmayla çalıştırır ve signed 29-bit Q15 sonucu 64-bit dış lane düzeninde yazar.

PHASE-06D sayısal doğrulaması dört kaynağı ayrı tutar: PHASE-02 NumPy floating golden, PHASE-06C idealize 29-bit Q15 mimari model, gerçek AMD bit-accurate C-model ve generated AMD FFT'nin XSim çıktısı. Zorunlu kabul C-model ile XSim'in tam kompleks integer çıktılarda bit-eşitliğidir; NumPy ve PHASE-06C farkları yalnız ayrı karakterizasyon ve algoritmik yapı çapraz kontrolüdür. FFT-output güç, PSD ve detector referansı bu fazda eklenmemiştir.

`rtl/fft_power.py` ve `rtl/power_vectors.py`, PHASE-06F için PHASE-06D'nin gerçek signed 29 bit FFT integer alanlarından exact `I²+Q²` hesaplar. Model Python arbitrary-precision integer aritmetiği kullanır; 58 bit `UQ28.30` sonuçta rounding, truncation veya saturation yoktur. PHASE-02 floating güç/PSD modeli ve PHASE-06D FFT vendor referansı ayrı katmanlar olarak korunur. PHASE-06F PSD normalization veya detector algoritması uygulamaz.

`rtl/regional_detector.py` ve `rtl/detector_vectors.py`, PHASE-06G için PHASE-03 `regional` matematiğini bağımsız integer/bit-true katmanda uygular. Natural↔shifted mapping, exact doubled even median, üç doğrulanmış Pfa için UQ*.24 noise/threshold, mask ve strict decision alanları üretilir. On beş sentetik ile beş frozen PHASE-06F real-power frame'i kullanılır. Floating `algorithms/detection/cfar.py`, bit-true model ve SystemVerilog birbirinden ayrı doğrulama katmanlarıdır; grouping/temporal/PHASE-04 parametre çıkarımı bu modelde yoktur.

`rtl/candidate_grouping.py` ve `rtl/candidate_vectors.py`, PHASE-06H için authoritative `DetectionPipeline._group` davranışını PHASE-06G integer hücre metadata'sına uygular. Shifted detected index farkı en fazla iki olduğunda aynı kaba aday oluşturulur; start/end ilk/son detected bindir, eşit peak'te ilk/düşük shifted bin kazanır ve peak-region noise/threshold korunur. On iki sentetik köşe frame'i ile bir frozen gerçek PHASE-06G frame'i kullanılır. Coarse span `end-start+1` olup precise bandwidth, Hz/dB, temporal association veya PHASE-04 parametre çıkarımı değildir.

`ps/candidate_transport.py` ve `ps/transport_vectors.py`, PHASE-06I little-endian ABI v1 packet'ını bağımsız Python encode/decode katmanında tanımlar. Header/record/trailer boyutları, frame ID, empty frame, count, status, reserved alanları, exact integer metadata ve payload CRC32 strict doğrulanır. Bu model DMA veya PS temporal runtime değildir.

`ps/temporal_confirmation.py` ve `ps/temporal_vectors.py`, PHASE-06J için yeni temporal kural icat etmeden PHASE-03 `DetectionPipeline._update_tracks` state machine'ini PHASE-06I packet candidate'larına uygular. Python katmanı C11 PS çekirdeğinin golden oracle'ıdır; uint32 wrap ardışık kabul edilir, diğer frame gap'leri reset üretir. Fiziksel Hz/dB dönüşümü veya gerçek DMA/PetaLinux davranışı içermez.
