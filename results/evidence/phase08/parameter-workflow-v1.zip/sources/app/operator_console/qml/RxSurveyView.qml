import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import Teknofest.Display 1.0

Item {
    id: view
    required property var theme
    readonly property var survey: operatorViewModel.survey
    signal fixedBandRequested()

    component Caption: Label {
        color: view.theme.textSecondary
        font.pixelSize: 11
    }
    component Action: Button {
        id: action
        implicitHeight: 36
        padding: 10
        contentItem: Text {
            text: action.text
            color: action.enabled ? view.theme.textPrimary : view.theme.textMuted
            font.pixelSize: 12
            horizontalAlignment: Text.AlignHCenter
            verticalAlignment: Text.AlignVCenter
        }
        background: Rectangle {
            radius: 4
            color: action.hovered ? view.theme.accentSoft : view.theme.surfaceAlt
            border.color: action.activeFocus ? view.theme.accent : view.theme.border
        }
    }
    component Card: Rectangle {
        color: view.theme.surface
        border.color: view.theme.border
        radius: 6
    }
    component FrequencyField: TextField {
        id: field
        color: view.theme.textPrimary
        font.family: "Consolas"
        font.pixelSize: 13
        implicitHeight: 36
        padding: 8
        horizontalAlignment: TextInput.AlignHCenter
        verticalAlignment: TextInput.AlignVCenter
        readonly property bool numericCentered: horizontalAlignment === TextInput.AlignHCenter
        background: Rectangle { radius: 4; color: "#313131"; border.color: field.activeFocus ? view.theme.accent : view.theme.border }
    }
    component GainChoice: ComboBox {
        id: gain
        implicitHeight: 36
        leftPadding: 20
        rightPadding: 20
        contentItem: Text { text: gain.displayText; color: gain.enabled ? view.theme.textPrimary : view.theme.textMuted; horizontalAlignment: Text.AlignHCenter; verticalAlignment: Text.AlignVCenter; font.family: "Consolas"; font.pixelSize: 13 }
        indicator: Canvas {
            x: gain.width - width - 10
            anchors.verticalCenter: parent.verticalCenter
            width: 10; height: 6
            onPaint: {
                var ctx = getContext("2d")
                ctx.reset(); ctx.strokeStyle = view.theme.textSecondary
                ctx.lineWidth = 1.5; ctx.lineCap = "round"
                ctx.beginPath(); ctx.moveTo(1,1); ctx.lineTo(width/2,height-1)
                ctx.lineTo(width-1,1); ctx.stroke()
            }
        }
        background: Rectangle { radius: 4; color: "#313131"; border.color: gain.activeFocus ? view.theme.accent : view.theme.border }
        delegate: ItemDelegate {
            required property var modelData
            width: gain.width
            text: String(modelData)
            contentItem: Text { text: parent.text; color: view.theme.textPrimary; font.pixelSize: 12; verticalAlignment: Text.AlignVCenter }
            background: Rectangle { color: parent.hovered ? view.theme.accentSoft : view.theme.surfaceAlt }
        }
        popup.background: Rectangle { color: view.theme.surfaceAlt; border.color: view.theme.border; radius: 4 }
    }

    ColumnLayout {
        anchors.fill: parent
        anchors.margins: 12
        spacing: 10
        Card {
            Layout.fillWidth: true
            implicitHeight: controls.implicitHeight + 28
            ColumnLayout {
                id: controls
                anchors.fill: parent
                anchors.margins: 14
                spacing: 12
                RowLayout {
                    Layout.fillWidth: true
                    Label { text: "BANT TARAMASI"; color: view.theme.textPrimary; font.pixelSize: 14; font.weight: Font.DemiBold }
                    Item { Layout.fillWidth: true }
                    Action { text: "Sabit Frekans ›"; enabled: !operatorViewModel.busy; onClicked: view.fixedBandRequested() }
                }
                RowLayout {
                    Layout.fillWidth: true
                    spacing: 10
                    ColumnLayout {
                        spacing: 3
                        Caption { text: "Alt sınır (MHz)"; Layout.fillWidth: true; horizontalAlignment: Text.AlignHCenter }
                        FrequencyField { id: lower; objectName: "surveyLowerMHz"; Layout.preferredWidth: 120; Layout.fillWidth: true; text: "1"; enabled: !operatorViewModel.busy; validator: DoubleValidator { bottom: 1; top: 6000; locale: "C" } Accessible.name: "Tarama alt sınırı megahertz" }
                    }
                    ColumnLayout {
                        spacing: 3
                        Caption { text: "Üst sınır (MHz)"; Layout.fillWidth: true; horizontalAlignment: Text.AlignHCenter }
                        FrequencyField { id: upper; objectName: "surveyUpperMHz"; Layout.preferredWidth: 120; Layout.fillWidth: true; text: "6000"; enabled: !operatorViewModel.busy; validator: DoubleValidator { bottom: 1; top: 6000; locale: "C" } Accessible.name: "Tarama üst sınırı megahertz" }
                    }
                    ColumnLayout {
                        spacing: 3
                        Caption { text: "Azami LNA (dB)"; Layout.fillWidth: true; horizontalAlignment: Text.AlignHCenter }
                        GainChoice { id: lna; objectName: "surveyLnaInput"; Layout.preferredWidth: 120; Layout.fillWidth: true; model: [0,8,16,24,32,40]; currentIndex: 2; enabled: !operatorViewModel.busy; Accessible.name: "Tarama azami LNA kazancı" }
                    }
                    ColumnLayout {
                        spacing: 3
                        Caption { text: "Azami VGA (dB)"; Layout.fillWidth: true; horizontalAlignment: Text.AlignHCenter }
                        GainChoice { id: vga; objectName: "surveyVgaInput"; Layout.preferredWidth: 120; Layout.fillWidth: true; model: [0,8,16,24,32,40,48,56]; currentIndex: 2; enabled: !operatorViewModel.busy; Accessible.name: "Tarama azami VGA kazancı" }
                    }
                    Item { Layout.fillWidth: true }
                    Action { visible: !operatorViewModel.hackrfReady; text: "Alıcıyı Denetle"; enabled: !operatorViewModel.busy; onClicked: operatorViewModel.probeHackrf() }
                    Action {
                        objectName: "surveyStart"
                        visible: !survey.running
                        text: "Taramayı Başlat"
                        enabled: operatorViewModel.hackrfReady && !operatorViewModel.busy && lower.acceptableInput && upper.acceptableInput && Number(lower.text) < Number(upper.text)
                        onClicked: operatorViewModel.startFrequencySurvey(Number(lower.text), Number(upper.text), Number(lna.currentText), Number(vga.currentText))
                    }
                    Action { objectName: "surveyStop"; visible: survey.running; text: "Taramayı Durdur"; enabled: survey.running && survey.state !== "Durduruluyor"; onClicked: survey.cancel() }
                }
                RowLayout {
                    visible: false
                    Layout.fillWidth: true
                    spacing: 8
                    Caption { text: "Kontrollü verici kanıtı"; font.weight: Font.Bold }
                    Action {
                        objectName: "surveyReferenceStart"
                        text: "1 · TX’İ KAPAT → REFERANS"
                        enabled: operatorViewModel.hackrfReady && !operatorViewModel.busy && lower.acceptableInput && upper.acceptableInput && Number(lower.text) < Number(upper.text)
                        onClicked: operatorViewModel.startReferenceSurvey(Number(lower.text), Number(upper.text), Number(lna.currentText), Number(vga.currentText))
                        ToolTip.visible: hovered
                        ToolTip.text: "Harici test vericisini gerçekten kapatın. Ortam ve alıcı çizgileri aynı ayarlarla kaydedilir."
                    }
                    Action {
                        objectName: "surveyComparisonStart"
                        text: "2 · TX’İ AÇ → KARŞILAŞTIR"
                        enabled: operatorViewModel.hackrfReady && !operatorViewModel.busy && survey.referenceReady && lower.acceptableInput && upper.acceptableInput && Number(lower.text) < Number(upper.text)
                        onClicked: operatorViewModel.startComparisonSurvey(Number(lower.text), Number(upper.text), Number(lna.currentText), Number(vga.currentText))
                        ToolTip.visible: hovered
                        ToolTip.text: "Harici test vericisini açın. Aynı frekans, gerçek kazanç ve süreyle referansa göre değişen adaylar ayrılır. Bu laboratuvar karşılaştırması yayıncı kimliğini veya saha başarısını kanıtlamaz."
                    }
                    Action { text: "Referansı Sil"; visible: survey.referenceReady; enabled: !operatorViewModel.busy; onClicked: survey.clearReference() }
                    Caption { text: survey.referenceText; Layout.fillWidth: true; wrapMode: Text.Wrap; color: survey.referenceReady ? view.theme.accent : view.theme.textSecondary }
                }
                Caption { visible: !!operatorViewModel.errorMessage; text: operatorViewModel.errorMessage; color: view.theme.danger; Layout.fillWidth: true; wrapMode: Text.Wrap }
                RowLayout {
                    visible: false
                    Layout.fillWidth: true
                    Caption { text: "Arama aralığı" }
                    Action { text: "1,3 GHz çevresi"; enabled: !operatorViewModel.busy; onClicked: { lower.text = "1280"; upper.text = "1330" } }
                    Action { text: "2,4 GHz çevresi"; enabled: !operatorViewModel.busy; onClicked: { lower.text = "2400"; upper.text = "2500" } }
                    Action { text: "5,8 GHz çevresi"; enabled: !operatorViewModel.busy; onClicked: { lower.text = "5725"; upper.text = "5875" } }
                    Action { text: "Tüm aralık"; enabled: !operatorViewModel.busy; onClicked: { lower.text = "1"; upper.text = "6000" } }
                    Caption { text: "600 kHz adımlı örtüşen 2 MHz ayarlar; kısa yayınlar yine kaçabilir."; Layout.fillWidth: true; wrapMode: Text.Wrap; font.pixelSize: 10 }
                }
            }
        }
        RowLayout {
            Layout.fillWidth: true
            Layout.fillHeight: true
            spacing: 10
            ColumnLayout {
                Layout.fillWidth: true
                Layout.fillHeight: true
                spacing: 10
                Card {
                    Layout.fillWidth: true
                    implicitHeight: coverageContent.implicitHeight + 28
                    ColumnLayout {
                        id: coverageContent
                        anchors.fill: parent
                        anchors.margins: 14
                        spacing: 8
                        RowLayout {
                            Layout.fillWidth: true
                            Caption { text: "TARAMA KAPSAMI"; font.weight: Font.Bold; Layout.fillWidth: true }
                            Caption { text: survey.timeText; font.family: "Consolas" }
                        }
                        Label { visible: survey.running && !survey.rechecking; text: survey.currentRange; color: view.theme.textPrimary; font.pixelSize: 20; font.family: "Consolas" }
                        Canvas {
                            id: coverageCanvas
                            objectName: "surveyCoverage"
                            Layout.fillWidth: true
                            Layout.preferredHeight: 20
                            Accessible.role: Accessible.ProgressBar
                            Accessible.name: survey.coverageText
                            Connections { target: view.survey; function onChanged() { coverageCanvas.requestPaint() } }
                            onPaint: {
                                var ctx = getContext("2d"), states = survey.coverage
                                ctx.reset(); ctx.fillStyle = view.theme.surfaceAlt; ctx.fillRect(0,0,width,height)
                                // Group by screen column: an error or unvisited window must not disappear under a completed neighbour.
                                for (var x = 0; x < Math.ceil(width); x++) {
                                    var a = Math.floor(x * states.length / width)
                                    var b = Math.min(states.length, Math.max(a + 1, Math.ceil((x + 1) * states.length / width)))
                                    var pending = false, failed = false
                                    for (var i = a; i < b; i++) { pending = pending || states[i] === 0; failed = failed || states[i] === 2 }
                                    ctx.fillStyle = failed ? view.theme.warning : pending ? view.theme.surfaceAlt : view.theme.accent
                                    ctx.fillRect(x,0,1,height)
                                }
                                if (survey.running && survey.currentIndex >= 0) {
                                    ctx.fillStyle = view.theme.textPrimary
                                    ctx.fillRect(survey.currentIndex * width / Math.max(1,states.length),0,2,height)
                                }
                            }
                        }
                        RowLayout {
                            Layout.fillWidth: true
                            Caption { text: survey.state; Layout.fillWidth: true }
                            Caption { text: Math.round(survey.progress * 100) + " %" }
                        }
                    }
                }
                Card {
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    ColumnLayout {
                        anchors.fill: parent
                        anchors.margins: 14
                        spacing: 8
                        RowLayout {
                            Layout.fillWidth: true
                            Caption { text: "SPEKTRUM"; font.weight: Font.Bold; Layout.fillWidth: true }
                            Caption { text: operatorViewModel.centerFrequencyText; font.family: "Consolas" }
                        }
                        Canvas {
                            id: spectrum
                            objectName: "surveySpectrum"
                            Layout.fillWidth: true
                            Layout.fillHeight: true
                            Layout.minimumHeight: 90
                            SpectrumTrace { anchors.fill: parent; z: -1; source: operatorViewModel.spectralDisplay }
                            Accessible.role: Accessible.Graphic
                            Accessible.name: "Son tarama penceresinin kalibrasyonsuz dBFS spektrumu"
                            Connections { target: operatorViewModel; function onSpectrumChanged() { spectrum.requestPaint() } }
                            onPaint: {
                                var ctx = getContext("2d")
                                ctx.reset(); ctx.clearRect(0,0,width,height)
                                var left = 42, w = Math.max(1,width-left-8), h = Math.max(1,height-20)
                                ctx.font = "9px Consolas"; ctx.textAlign = "right"
                                for (var i = 0; i <= 4; i++) {
                                    var y = 8+i*(h-16)/4
                                    ctx.strokeStyle = view.theme.border; ctx.beginPath(); ctx.moveTo(left,y); ctx.lineTo(width,y); ctx.stroke()
                                    ctx.fillStyle = view.theme.textSecondary
                                    ctx.fillText((operatorViewModel.spectrumMaxDb-i*(operatorViewModel.spectrumMaxDb-operatorViewModel.spectrumMinDb)/4).toFixed(0),left-6,y+3)
                                }
                            }
                        }
                        WaterfallImage {
                            objectName: "surveyWaterfall"
                            visibleRows: 8
                            Layout.fillWidth: true
                            Layout.preferredHeight: Math.max(60, Math.min(120, view.height * 0.14))
                            source: operatorViewModel.spectralDisplay
                            Accessible.name: "Son tamamlanan tarama penceresinin spektrogramı; frekans değişince geçmiş temizlenir"
                        }
                        RowLayout {
                            Layout.fillWidth: true
                            Caption { text: operatorViewModel.sourceReady ? ((operatorViewModel.centerFrequencyHz-1e6)/1e6).toFixed(3)+" MHz" : "—" }
                            Item { Layout.fillWidth: true }
                            Caption { text: operatorViewModel.sourceReady ? ((operatorViewModel.centerFrequencyHz+1e6)/1e6).toFixed(3)+" MHz" : "—" }
                        }
                    }
                }
            }
            Card {
                Layout.preferredWidth: 320
                Layout.fillHeight: true
                ColumnLayout {
                    anchors.fill: parent
                    anchors.margins: 14
                    spacing: 8
                    Label { text: "BULUNAN SİNYALLER"; color: view.theme.textPrimary; font.pixelSize: 12; font.weight: Font.DemiBold }
                    Caption { visible: observationList.count === 0; text: survey.running ? "Sinyal aranıyor" : survey.progress > 0 ? "Sinyal bulunamadı" : "Taramayı başlatın"; color: view.theme.accent; Layout.fillWidth: true }
                    ListView {
                        id: observationList
                        objectName: "surveyObservations"
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        clip: true
                        spacing: 4
                        model: survey.observationModel
                        reuseItems: true
                        onCountChanged: if (count > 0) positionViewAtBeginning()
                        ScrollBar.vertical: ScrollBar {}
                        delegate: Button {
                            required property var modelData
                            width: observationList.width
                            height: (modelData.rangeText ? 70 : 50) + (modelData.recheckStatus ? 18 : 0)
                            Accessible.name: modelData.frequency + ", " + (modelData.signalDetected ? "Sinyal tespit edildi" : "Doğrulama bekliyor")
                            ToolTip.visible: hovered
                            ToolTip.text: modelData.detail + "\n" + modelData.evidenceDetail + (modelData.checkedAt ? "\nSon kontrol: " + modelData.checkedAt : "")
                            onClicked: survey.selectObservation(modelData.eventId)
                            background: Rectangle {
                                radius: 4
                                color: survey.selectedKey === modelData.eventId || modelData.latestWindow ? view.theme.accentSoft : view.theme.surfaceAlt
                                border.color: survey.selectedKey === modelData.eventId || modelData.latestWindow ? view.theme.accent : view.theme.border
                            }
                            contentItem: Column {
                                spacing: 3
                                Row {
                                    width: parent.width
                                    spacing: 8
                                    Label { text: modelData.frequency; color: view.theme.textPrimary; font.family: "Consolas"; font.pixelSize: 14 }
                                }
                                Caption { visible: !modelData.signalDetected; text: "Doğrulama bekliyor"; color: view.theme.warning; font.pixelSize: 10 }
                                Caption { visible: !!modelData.rangeText; text: modelData.rangeText || ""; color: view.theme.textSecondary; width: parent.width; elide: Text.ElideRight }
                                Caption { visible: !!modelData.recheckStatus; text: modelData.recheckStatus || ""; color: view.theme.textSecondary; font.pixelSize: 10 }
                            }
                        }
                    }
                    Action {
                        objectName: "surveyMonitor"
                        Layout.fillWidth: true
                        text: survey.running ? "Önce taramayı durdurun" : "Sinyali Yeniden Al"
                        enabled: !operatorViewModel.busy && survey.selectedFrequency > 0
                        onClicked: if (operatorViewModel.monitorSurveyObservation()) view.fixedBandRequested()
                    }
                }
            }
        }
    }
}
