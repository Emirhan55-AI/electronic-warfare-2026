import json
import os
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
os.environ['QT_QPA_PLATFORM'] = 'offscreen'
os.environ['QT_QUICK_BACKEND'] = 'software'
from app.operator_console.quick_application import build_quick_application

OUT = Path(__file__).resolve().parent
app, engine, vm = build_quick_application(['parameter-inspection'])
root = engine.rootObjects()[0]
root.setProperty('spectrumTaskTab', 1)

def drain(predicate=lambda: False, seconds=0.4):
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        app.processEvents()
        if predicate():
            return
        time.sleep(0.002)

def capture(state):
    for width, height in [(1280, 720), (1920, 1080)]:
        root.setWidth(width)
        root.setHeight(height)
        drain()
        assert root.grabWindow().save(str(OUT / f'{state}-{width}.png'))

capture('empty')
vm.openSigmf(str(ROOT / 'datasets/fixtures/phase01/known-tone-ci8.sigmf-meta'))
drain(lambda: not vm.busy and vm.sourceReady, 8)
vm.startScan()
drain(lambda: vm.frameIndex >= 4 and any(x['stateKey'] == 'confirmed' for x in vm.detections), 8)
vm.pause()
drain(lambda: not vm.busy, 8)
event = next(x for x in vm.detections if x['stateKey'] == 'confirmed')
vm.selectDetection(int(event['eventId']))
peak = vm.selectedRegionPeakNormalized
vm.setAnalysisSpanDraftNormalized(peak - .004, peak + .004)
vm.confirmAnalysisSpan(float(vm.analysisLowerMHzText), float(vm.analysisUpperMHzText))
capture('approved-range')
vm.requestMeasurement()
drain(lambda: not vm.busy, 8)
assert vm.parameterRows
from app.operator_console.measurement_record import read_measurement, replay_measurement, digest
record_path = Path(vm.measurementRecordPath)
record_bytes = record_path.read_bytes()
(OUT / 'sample-record.zip').write_bytes(record_bytes)
replay_measurement(record_path)
(OUT / 'sample-summary.json').write_text(json.dumps({'archive': 'sample-record.zip', 'sha256': digest(record_bytes), 'replay': 'passed'}, indent=2), encoding='utf-8')
capture('recorded-result')
from PySide6.QtCore import QObject
panel=root.findChild(QObject, 'measurementScroll')
panel.setProperty('detailsOpen', True)
capture('details')
(OUT / 'ui-inspection.json').write_text(json.dumps({
    'source': 'datasets/fixtures/phase01/known-tone-ci8.sigmf-meta',
    'physical_rf': False,
    'rows': list(vm.parameterRows),
    'status': vm.statusMessage,
    'profile_ready': vm.parameterCapabilityReady,
}, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
vm.shutdown()
root.close()
