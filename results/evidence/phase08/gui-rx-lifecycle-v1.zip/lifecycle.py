from pathlib import Path
import sys,time,json,hashlib,subprocess
from datetime import datetime,timezone
sys.path.insert(0,str(Path.cwd()))
from PySide6.QtCore import QTimer
from scripts.measure_live_gui_fpga import ObservedSession
from app.operator_console.quick_application import build_quick_application

out=Path(__file__).with_name('lifecycle-01.json')
assert not out.exists()
sources={n:hashlib.sha256(Path(n).read_bytes()).hexdigest() for n in subprocess.check_output(['git','ls-files','app/operator_console','platforms/acquisition','algorithms/p0'],text=True).splitlines() if Path(n).suffix in ('.py','.qml','.cpp','.h')}
app,engine,view=build_quick_application(['lifecycle-measurement'])
app.setQuitOnLastWindowClosed(False)
window=engine.rootObjects()[0]; window.setWidth(1440);window.setHeight(900)
window.setTitle('BÂZ · Kısa durdur/başlat ve pencereye dönüş testi')
window.setProperty('rfSearchMode',False)
sessions=[]; rows=[]; shown=[]; events=[]; started=time.perf_counter(); stage='probe'; stage_at=started
closed=False; stop_at=None; restart_at=None; done=False
def factory(*a,**kw):
    s=ObservedSession(*a,**kw);sessions.append(s);return s
view._live_session_factory=factory
def mark(name,**extra):
    row={'event':name,'seconds':time.perf_counter()-started,**extra};events.append(row);print(json.dumps(row),flush=True)
def on_close():
    global closed
    closed=True
window.closing.connect(on_close)
def swapped():
    if view.liveSessionActive and view._live_received_at:
        now=time.perf_counter(); key=(view._generation,view._frame_index)
        if not shown or tuple(shown[-1][:2])!=key:shown.append([*key,now-started,(now-view._live_received_at)*1000])
window.frameSwapped.connect(swapped)
def finish(reason):
    global done
    if done:return
    done=True;timer.stop();view.shutdown()
    report={'recorded_at':datetime.now(timezone.utc).isoformat(),'requirements':['KTR-4.1','KTR-4.1-OPS-B0'],'scope':'same_application_stop_restart_and_desktop_return_observation','external_transmitter_state':'operator_declared_off','transmit_enabled':False,'ST06_complete':False,'reason':reason,'events':events,'samples_columns':['seconds','stage','generation','display_sequence','rx_received_monotonic','fpga_response_monotonic','exposed','visible'],'samples':rows,'presentation_columns':['generation','sequence','seconds','host_rx_age_ms'],'presentations':shown,'sessions':[s.observation for s in sessions],'source_sha256':sources,'sources_unchanged':all(hashlib.sha256(Path(n).read_bytes()).hexdigest()==h for n,h in sources.items()),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'limits':['İptal edilen oturumun son USB istatistiği yoksa sıfır hata kabul edilmez.','Önceki kart kimliği bu kısa koşuda yeniden okunmadı; bitstream kimliği doğrulanmış sayılmaz.']}
    out.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');mark('saved',reason=reason);window.close();app.quit()
def poll():
    global stage,stage_at,stop_at,restart_at
    now=time.perf_counter()
    rows.append([now-started,stage,view._generation,view._frame_index,view._live_received_at,view._live_response_at,window.isExposed(),window.isVisible()])
    if closed:return finish('operator_closed')
    if now-started>190:return finish('watchdog')
    if stage=='probe' and not view.busy:
        if not view.hackrfReady:return finish('probe_failed')
        view.startLiveEDSession(900000000,0,0,58594);stage='first';stage_at=now;mark('first_started',generation=view._generation)
    elif stage=='first':
        if not view.busy:return finish('first_ended_early')
        if now-stage_at>=30:
            stop_at=now;view.stopLiveEDSession();stage='stopping';mark('stop_requested')
    elif stage=='stopping' and not view.busy:
        proc=getattr(sessions[0].stream_observed,'_process',None)
        mark('stopped',stop_latency_ms=(now-stop_at)*1000,receiver_process_returncode=proc.poll() if proc else None,error=sessions[0].observation.get('error'))
        view.startLiveEDSession(900000000,0,0,43945);restart_at=now;stage='second';stage_at=now
        mark('restarted',generation=view._generation,initial_frame=view._frame_index,initial_rx_at=view._live_received_at,initial_fpga_at=view._live_response_at)
    elif stage=='second':
        if not view.busy:return finish('second_completed')
        if now-stage_at>=15 and not any(e['event']=='desktop_switch_ready' for e in events):mark('desktop_switch_ready')
timer=QTimer();timer.setInterval(50);timer.timeout.connect(poll)
view.setSourceMode('hackrf');view.probeHackrf();timer.start();app.exec()
