#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <inttypes.h>
#include <sched.h>
#include <time.h>
#include SOURCE
static uint32_t state=6100701;
static uint32_t rnd(void){state^=state<<13;state^=state>>17;state^=state<<5;return state;}
static uint64_t tick(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000ULL+t.tv_nsec;}
int main(void){double a[256],b[256],expected,actual;size_t n,i,run,pattern;cpu_set_t set;
CPU_ZERO(&set);CPU_SET(1,&set);if(sched_setaffinity(0,sizeof(set),&set))return 2;
for(n=64;n<=256;n*=4)for(pattern=0;pattern<10;pattern++)for(run=0;run<2064;run++){
 uint64_t start,elapsed;
 for(i=0;i<n;i++){
  switch(pattern){
   case 0:a[i]=1;break;
   case 1:a[i]=(double)i;break;
   case 2:a[i]=(double)(n-i);break;
   case 3:a[i]=(double)(i%7);break;
   case 4:a[i]=(i%2)?1e12:1e-12;break;
   case 5:a[i]=(double)(i<n/2?i:n-i);break;
   case 6:a[i]=i==run%n?1e12:0;break;
   case 7:a[i]=(double)(rnd()%2);break;
   case 8:a[i]=(double)(rnd()%16);break;
   default:a[i]=(double)rnd()/4294967296.0;break;
  }
 }
 memcpy(b,a,n*sizeof(double));qsort(b,n,sizeof(double),compare_double);
 expected=0.5*(b[n/2-1]+b[n/2]);start=tick();actual=median(a,n);elapsed=tick()-start;
 if(memcmp(&expected,&actual,sizeof(double)))return 1;
 if(run>=64)printf("%zu,%zu,%zu,%" PRIu64 "\n",n,pattern,run-64,elapsed);
}
return 0;}
