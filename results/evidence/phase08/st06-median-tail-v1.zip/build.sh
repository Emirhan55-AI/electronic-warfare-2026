#!/bin/bash
set -eu
cd /tmp/st06-median-tail
base=/home/emirhan/projects/electronic-warfare-zedboard/build/tmp/work/zynq_generic_7z020-amd-linux-gnueabi/p0-dma/1.0
for v in baseline median; do
 "$base/recipe-sysroot-native/usr/bin/arm-amd-linux-gnueabi/arm-amd-linux-gnueabi-gcc" -std=c11 -O3 -Wall -Wextra -Werror -pedantic -mthumb -mfpu=neon -mfloat-abi=hard -mcpu=cortex-a9 -D_TIME_BITS=64 -D_FILE_OFFSET_BITS=64 --sysroot="$base/recipe-sysroot" -I. -DSOURCE=\"wide-$v.c\" tail.c -lm -o tail-$v
done
