#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <inttypes.h>
#include <string.h>
#include <sched.h>
#include <time.h>
#include "p0_st05_stream.h"
#include "p0_pl_os_cfar.h"

static uint64_t tick(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000ULL+t.tv_nsec;}
int main(int argc,char **argv){
 uint8_t raw[32768],det[4096];uint64_t uq[4096],start,total=0,hash=1469598103934665603ULL;double power[4096];int marked,valid;unsigned i;FILE *f;void *state;cpu_set_t set;p0_st05_result_t result;
 if(argc!=2)return 1;
 CPU_ZERO(&set);CPU_SET(1,&set);if(sched_setaffinity(0,sizeof(set),&set))return 2;
 f=fopen(argv[1],"rb");if(!f)return 3;if(fread(raw,1,sizeof(raw),f)!=sizeof(raw))return 4;fclose(f);
 if(p0_pl_os_cfar_decode(raw,sizeof(raw),uq,power,det,&marked))return 5;
 state=calloc(1,p0_st05_stream_state_bytes());if(!state)return 6;
 for(i=0;i<2064;i++){

  start=tick();if(p0_st05_stream_update(state,p0_st05_stream_state_bytes(),power,4096,&result,&valid))return 7;
  if(i>=64)total+=tick()-start;
  {size_t j;const unsigned char *b=(const unsigned char *)&result;for(j=0;j<sizeof(result);j++){hash^=b[j];hash*=1099511628211ULL;}}
 }
 printf("{\"frames\":2000,\"total_ns\":%" PRIu64 ",\"result_hash\":%" PRIu64 "}\n",total,hash);free(state);return 0;
}
