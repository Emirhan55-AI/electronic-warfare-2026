"""Bounded Qt presentation of a receive survey and historical observations."""

from pathlib import Path
import math
import time
from uuid import uuid4
from dataclasses import replace
from collections import deque
import threading

from PySide6.QtCore import QObject, Property, QRunnable, QTimer, Signal, Slot

from .detection_model import DetectionListModel
from .rx_survey import ROOT, RXSurvey, SurveyConfig, SurveyResult, SurveyUpdate
from algorithms.spectrum import SpectrumProcessor
from platforms.acquisition.source import decode_ci8


MAX_DISPLAY_OBSERVATIONS = 4096


class _SurveyMailbox:
    """Coalesce previews only; bounded control updates preserve coverage order."""

    def __init__(self):
        self.condition = threading.Condition()
        self.items = deque()
        self.pending = False

    def publish(self, update, cancelled):
        with self.condition:
            if (update.state == "preview" and self.items and self.items[-1].state == "preview"
                    and self.items[-1].window == update.window):
                self.items[-1] = update
                return False
            while len(self.items) >= 64:
                if cancelled():
                    return False
                self.condition.wait(.1)
            self.items.append(update)
            notify = not self.pending
            self.pending = True
            return notify

    def take(self):
        with self.condition:
            items = tuple(self.items)
            self.items.clear()
            self.pending = False
            self.condition.notify_all()
            return items


class _Signals(QObject):
    update = Signal(object)
    complete = Signal(object)
    failed = Signal(str)


class _Task(QRunnable):
    def __init__(self, survey):
        super().__init__()
        self.survey = survey
        self.signals = _Signals()
        self.mailbox = _SurveyMailbox()
        self.processor = SpectrumProcessor()

    def _publish(self, update):
        if update.state == "preview" and update.snapshot is not None:
            frame = update.snapshot.output_frame
            spectrum = self.processor.process(decode_ci8(frame.payload, expected_complex_samples=4096),
                sample_rate_hz=frame.sample_rate_hz, center_frequency_hz=frame.center_frequency_hz)
            update = replace(update, prepared_spectrum=spectrum)
        cancelled = lambda: bool(getattr(self.survey, "_cancel", threading.Event()).is_set())
        if self.mailbox.publish(update, cancelled):
            self.signals.update.emit(self.mailbox)

    def run(self):
        try:
            result = self.survey.run(self._publish)
        except Exception as exc:
            self.signals.failed.emit(str(getattr(exc, "code", type(exc).__name__)))
        else:
            self.signals.complete.emit(result)


class SurveyController(QObject):
    changed = Signal()
    preview = Signal(object)
    finished = Signal(str)

    def __init__(self, parent=None, *, factory=RXSurvey):
        super().__init__(parent)
        self._factory = factory
        self._survey = None
        self._config = SurveyConfig()
        self._windows = self._config.windows()
        self._states = [0] * len(self._windows)
        self._current = -1
        self._good = self._bad = self._observed = 0
        self._rows = []
        self._current_observation_count = 0
        self._model = DetectionListModel(self)
        self._selected = ""
        self._state = "Hazır"
        self._detail = "Frekansı bilinmeyen yayın için sırayla alım."
        self._audit = ""
        self._started = 0.0
        self._elapsed = 0.0
        self._timer = QTimer(self)
        self._timer.setInterval(500)
        self._timer.timeout.connect(self._tick)

    @Property(bool, notify=changed)
    def running(self):
        return self._survey is not None

    @Property(str, notify=changed)
    def state(self):
        return self._state

    @Property(str, notify=changed)
    def detail(self):
        return self._detail

    @Property(str, notify=changed)
    def coverageText(self):
        return f"{self._good} / {len(self._states)} pencere tarandı · {self._bad} hata"

    @Property(float, notify=changed)
    def progress(self):
        return self._good / max(1, len(self._states))

    @Property("QVariantList", notify=changed)
    def coverage(self):
        return self._states

    @Property(int, notify=changed)
    def currentIndex(self):
        return self._current

    @Property(str, notify=changed)
    def currentRange(self):
        if self._current < 0:
            return "Pencere bekleniyor"
        item = self._windows[self._current]
        return f"{item.lower_hz / 1e6:.3f}–{item.upper_hz / 1e6:.3f} MHz"

    @Property(str, notify=changed)
    def timeText(self):
        elapsed = f"{int(self._elapsed) // 60:02d}:{int(self._elapsed) % 60:02d}"
        count = self._good + self._bad
        if not self.running or count < 3:
            return f"Geçen {elapsed}"
        remaining = self._elapsed / count * (len(self._states) - count)
        return f"Geçen {elapsed} · kalan yaklaşık {remaining / 60:.0f} dk"

    @Property(str, notify=changed)
    def auditPath(self):
        return self._audit

    @Property(str, notify=changed)
    def observationText(self):
        if self._observed > len(self._rows):
            return f"{len(self._rows)} gösteriliyor / {self._observed} RF gözlemi · tamamı kayıtta"
        return f"{self._observed} kararlı RF gözlemi"

    @Property(str, notify=changed)
    def currentObservationText(self):
        if self._current < 0:
            return "Aktif pencere bekleniyor"
        if self._current_observation_count == 0:
            return "Son pencerede kararlı RF gözlemi yok"
        return f"Son pencerede {self._current_observation_count} kararlı RF gözlemi"

    @Property(QObject, constant=True)
    def observationModel(self):
        return self._model

    @Property(str, notify=changed)
    def selectedKey(self):
        return self._selected

    @Property(float, notify=changed)
    def selectedFrequency(self):
        return next((row["frequencyHz"] for row in self._rows if row["eventId"] == self._selected), 0.0)

    @Slot(str)
    def selectObservation(self, key):
        if any(row["eventId"] == key for row in self._rows):
            self._selected = key
            self.changed.emit()

    def start(self, executable, serial, config, pool, *, audit_path=None):
        if self.running:
            return False
        self._config = config
        self._windows = config.windows()
        self._states = [0] * len(self._windows)
        self._current = -1
        self._good = self._bad = self._observed = 0
        self._rows = []
        self._current_observation_count = 0
        self._model.set_rows([])
        self._selected = ""
        self._elapsed = 0.0
        self._started = time.monotonic()
        self._audit = str(audit_path or (ROOT / "build" / "acceptance" / "rx-survey" / f"{uuid4().hex}.jsonl"))
        self._survey = self._factory(executable, serial, config, Path(self._audit))
        task = _Task(self._survey)
        task.signals.update.connect(self._update)
        task.signals.complete.connect(self._complete)
        task.signals.failed.connect(self._failed)
        self._state = "Taranıyor"
        self._detail = "Her pencere kart yanıtı ve alım bütünlüğü denetlenerek işlenir."
        self._timer.start()
        self.changed.emit()
        pool.start(task)
        return True

    @Slot()
    def cancel(self):
        if self._survey is not None:
            self._state = "Durduruluyor"
            self._survey.cancel()
            self.changed.emit()

    def _tick(self):
        if self.running:
            self._elapsed = time.monotonic() - self._started
            self.changed.emit()

    @Slot(object)
    def _update(self, update: SurveyUpdate):
        if isinstance(update, _SurveyMailbox):
            for item in update.take():
                self._update(item)
            return
        self._current = update.window.index
        self._elapsed = update.elapsed_seconds
        if update.state == "preview":
            if update.prepared_spectrum is not None:
                self.preview.emit((update.snapshot, update.prepared_spectrum))
            return
        if update.state == "running":
            self.preview.emit(None)
            self._detail = "Alım önizlemesi · pencere bütünlüğü henüz doğrulanmadı."
        if update.state == "complete":
            self._states[self._current] = 1
            self._good += 1
            newest = []
            for item in update.observations:
                self._observed += 1
                event = item.get("event") or {}
                peak, noise = float(event.get("peak_power", 0.0)), float(event.get("noise_power", 0.0))
                ratio = 10.0 * math.log10(peak / noise) if peak > 0.0 and noise > 0.0 else float("nan")
                verification = item.get("verification") or {}
                details = [
                    f"P/N {ratio:.1f} dB" if math.isfinite(ratio) else "P/N ölçülemedi",
                    f"{item['observed_frames']} kare",
                ]
                bandwidth_hz = float(item.get("bandwidth_hz", 0.0))
                if bandwidth_hz >= 1_000_000:
                    details.append(f"kaba aralık {bandwidth_hz / 1e6:.2f} MHz")
                elif bandwidth_hz > 0.0:
                    details.append(f"kaba aralık {bandwidth_hz / 1e3:.1f} kHz")
                if verification:
                    details.append(f"2. ayar {verification.get('observed_frames', 0)} kare")
                newest.append({
                    "eventId": item["key"], "frequencyHz": item["frequency_hz"],
                    "frequency": f"{item['frequency_hz'] / 1e6:.6f} MHz",
                    "detail": " · ".join(details),
                    "window": f"Pencere {self._current + 1}",
                    "latestWindow": True,
                })
            self._current_observation_count = len(newest)
            for row in self._rows:
                row["latestWindow"] = False
            if newest:
                # New detections must remain visible during a long survey instead of
                # being buried below thousands of historical observations.
                self._rows = (newest + self._rows)[:MAX_DISPLAY_OBSERVATIONS]
            self._model.set_rows(self._rows)
            self._detail = "Pencere alımı ve kart yanıtları doğrulandı; bu bir geçmiş gözlemdir."
        elif update.state == "failed":
            self.preview.emit(None)
            self._states[self._current] = 2
            self._bad += 1
            self._current_observation_count = 0
            self._detail = f"Pencere işlenemedi: {update.error_code}"
        self.changed.emit()

    @Slot(object)
    def _complete(self, result: SurveyResult):
        self._timer.stop()
        self._survey = None
        self._elapsed = result.elapsed_seconds
        self._state = {"completed": "Tur tamamlandı", "cancelled": "Durduruldu",
                       "partial": "Eksik kapsam", "failed": "Tarama hatası"}[result.state]
        self._detail = ("Bu turdaki geçmiş gözlemler; şu anda yayın yapıldığını göstermez."
                        if not result.error_code else f"Tarama durdu: {result.error_code}")
        self.changed.emit()
        self.finished.emit(result.state)

    @Slot(str)
    def _failed(self, code):
        self._timer.stop()
        self._survey = None
        self._state = "Tarama hatası"
        self._detail = f"Tarama tamamlanamadı: {code}"
        self.changed.emit()
        self.finished.emit("failed")
