# Parametre iyileştirme protokolü — 9 Eylül 2026

## v8/v9 bant kapsamı düzeltmesi

Kullanıcı vericinin kapalı olduğunu bildirdi; bu geliştirme kayıtlı I/Q
ve sayısal üreticiyle yürütüldü. v8 eşit kuyruklu OBW99 için her uçta ayrı
%0,5 sınırı ve Hann dördüncü moment varyans şişirmesini ekledi. Bağımsız
uzun kayıt üreticisinde geniş kuyruklu BPSK'nin 24 örneğinden ikisi yanlış
geçerli kaldı. v9 uzak gürültüyü sekiz ayrı bölgenin en düşük medyanıyla
muhafazakâr kestirir; sinyal kuyruğunun gürültü diye çıkarılmasını azaltır.
Bu yaklaşım renkli gürültüde daha fazla ret verebilir; kalibre güven aralığı
veya genel RF doğruluk iddiası değildir.

`validate_candidate_numeric.py` 262144 örnekli temiz referans ile ayrı
16384 örnekli gürültülü gözlemi karşılaştırır. 23000000 köklü geliştirme
koşusundan sonra yöntem değiştirilmeden 24000000 köklü 168 örnek sınandı:
altı desteklenen ailede 96/144 OBW sonucu üretildi ve 96/96 toleransı geçti;
12 dB zaman alanı SNR'li 48 örnekte OBW reddedildi. Tam emisyonu aralığı
aşan dikdörtgen BPSK 24/24 reddedildi. Aynı tohumun SNR varyantları bağımsız
dalga biçimi sayılmaz. Tolerans `max(2×488,28125 Hz, referansın %10'u)`.
Bu sınırlı deney genel OBW kabulü değildir.

800 örneklik eski sınıf kararları değişmedi; eski RF regresyonu AM 16/20,
FM 20/20 Analog. Geniş alıcı bozulma kümesinde OBW verme sayısı aile başına
33–57/100'e düştü; bu maliyet korunur, yalnız geçerli sonuçlar sunularak
başarıya çevrilmez. 28 birim/profil/kayıt testi geçti. Ürün ve ARM yolu
değişmedi. Sıradaki fiziksel kontrol aynı model ve yöntemle farklı frekans/
ton ayarında yapılır; model/eşik bu koşunun sonucuna göre ayarlanmaz.

Yeni `capture_parameter_candidate_rx.py` yalnız iki sonlu 0,5 saniye RX
kaydı alır; TX veya FPGA çalıştırmaz. Model özeti, ham I/Q, ayar, zaman,
kırpılma ve onar pencere sonucu saklanır. Ürün akışı kabulü değildir.

KTR-4.2 / KTR-4.2-F1. Kullanıcının parametre çıkarımını düzeltme talebi,
PÇ-02 sayısal yöntem geliştirmesi ve PÇ-03 sınıflandırma çalışması kapsamındadır.
Mevcut F5 ürün profili, özgün yöntem kilitleri ve geçmiş kanıtlar korunur.
Yeni `refined_candidate` ürün tarafından çağrılmaz; geliştirme adayıdır.

## Yöntem ve veri ayrımı

- Dört ardışık 4096 örnek üzerinde 16384 örnek Hann spektrumu. Taşıyıcı
  yerine önce açıkça çizgi adayı bulunur; FM yan bandının taşıyıcı sayılması
  yasaktır. Uzun gözlem aynı I/Q içindedir; yeni donanım verisi değildir.
- İki taraflı gürültü referansı, kırpılma, düşük SNR ve aralık kenarı retleri.
  %0,5/%99,5 kümülatif kenar tanımı korunur; adayın üç gürültü düzeyli
  bastırması deneysel olduğu için ITU uygunluğu iddiası oluşturmaz.
- Özellikler gözlenen bant desteğine göre filtreleme/örnek azaltma sonrası
  zarf, faz farkı, moment ve korelasyonlardan çıkarılır. Ağaç modeli yalnız
  sayısal geliştirme verisiyle eğitilir. Sklearn geliştirme içindir; açık
  JSON ağacı yürütücüsü kod/pickle yüklemez. Model ürün paketine alınmaz.
- Sınıflar AM/NFM ve OOK/FSK/BPSK/QPSK/QAM; CW ayrı Belirsiz kontrolüdür.
  Sabit 0,9 ağaç oy eşiği kalibre doğruluk yüzdesi değildir. Bilinmeyen
  ailelerin güvenli reddi ayrı zorunlu kapıdır.

v1: 1100000 geliştirme, 2200000 kalibrasyon, 3300000 test kök tohumları.
Aile başına 10000 tohum ofseti kullanılır. Eğitim 120, kalibrasyon 40,
test 60 örnektir. Aynı üretici kullandığından test bağımsız tohum testidir;
bağımsız üretici veya saha genellemesi değildir. AM/NFM testinde 59/60'ar
doğru, birer Belirsiz; beş sayısal ailede 60/60'ar doğru, CW 60/60 Belirsiz.
Gerçek yüksek kazanç AM/FM regresyonunda 40/40 Belirsiz kaldı; v1 kabul edilmedi.

v2: alıcı düşük genliği, bağımsız DC/IQ dengesizliği ve 8 bit nicemleme
simülasyonu eklenir. 4400000/5500000/6600000 ayrık kök tohumları kullanılır;
aile başına 240/60/80 örnek. Model, test üretilmeden önce JSON olarak yazılıp
hash'lenir. Test sonrası eşik değiştirilmez. Başarısız sürüm raporu korunur.
Gerçek AM/FM kayıtları yalnız regresyondur: geliştirme boyunca incelendikleri
için sonraki kör fiziksel kabulün yerine geçemezler.

v2 sonucu: desteklenen ailelerde karar kapsamı %50–81,25; genel kapı
başarısız. Gerçek regresyonda AM 0/20, FM 16/20 Analog; diğerleri Belirsiz.
DC ofseti zayıf çizgi ve güç ölçümünü bozduğu için sayısal kabul de yapılmaz.

v3: nicemleme 8 MS/s'de, ardından 4:1 örnek azaltma; tohum kökleri
7700000/8800000/9900000, adetler 240/60/80. Gerçek regresyon AM 0/20,
FM 20/20 Analog; ürün kabulü yok.

v4: sabit alıcı DC'si örnek ortalamasıyla çıkarılır; LO merkezindeki baskın
çizgi belirsizdir. 12100000/13200000/14300000, adetler 240/60/80.
Testte modülasyonlu ailelerin doğru karar kapsamı %85–97,5, yanlış kesin
karar sıfır; CW 80/80 Belirsiz. 60 gürültü/chirp/iki-ton kontrolü Belirsiz;
JSON yürütücüsü test kararlarıyla eşleşti. Bu yalnız sınırlı sentetik sınıf
kapısıdır; tüm kapsam dışı ailelerin reddi değildir. Gerçek AM 1/20, FM
20/20 Analog. CW/AM geçerli çizgi hatasının %95 yüzdeliği yaklaşık 2 Hz;
bu kalibre fiziksel frekans değil sayısal üreteç karşılaştırmasıdır.

v5: AM %100 derinlik sınırı geliştirme örneklerinin dörtte birinde açıkça
temsil edildi. 15400000/16500000/17600000 kökleri, adetler 480/80/100.
Gerçek regresyonda AM 10/20, FM 20/20 Analog. v6 çizgiye göre özellik
merkezlemesi ve koherent ortalama özelliği ekler; kökler
18700000/19800000/20900000, adetler 480/80/100. İki sürümün testleri
birleştirilerek örnek sayısı veya başarı oranı artırılmaz.

Önceki sürümlerin kaynakları, model JSON'ları ve raporları ayrı dizinlerde
saklanır. Başarısızlıklar yeni yöntem kabulüne çevrilmez. Geliştirme
üreticisi aynıdır; bağımsız tohum ve alıcı bozulma dağılımı tek başına
bağımsız algoritma/üretici doğrulaması anlamına gelmez.

v6 sonucu: 800 test örneğinde AM 86/100, NFM 89/100, OOK 89/100,
FSK 82/100, BPSK 89/100, QPSK 85/100, QAM 93/100 doğru kesin karar;
kalan modülasyonlu örnekler Belirsiz, yanlış kesin karar sıfır. CW
100/100 Belirsiz. JSON yürütücüsü eğitim kitaplığıyla aynı test kararlarını
verdi; 60 sınırlı negatif kontrolün tamamı Belirsiz. Gerçek eski kayıt
regresyonu AM 16/20, FM 20/20 Analog; dört AM Belirsiz. Önceden incelenen
iki fiziksel kayıt/aile genel kabul paydası değildir.

Bağımsız mevcut 30 örneklik başlangıç üreticisinde AM/NFM 12/12 Analog,
FSK 6/6 Sayısal; CW 6/6 Belirsiz. BPSK'nin uzun kuyrukları seçilen
aralığa sığmadığı halde aday OBW ürettiği için sayısal bant kapısı başarısızdır.
CW/AM/NFM bu kümedeki bant farkları yaklaşık +337/+195/−174 Hz düzeyine
inse de bu iyileşme BPSK başarısızlığını kapatmaz.

v7 model eğitmez; v6 modelini aynı baytlarla kullanır. Aralık dışındaki
toplam enerjiye gürültü belirsizliği ekleyerek %1 sınırı aşılırsa yalnız
`obw99_hz` alanını boş bırakır; `bandwidth_reason` nedenini taşır. Diğer
alanlar bağımsız kalır. Bu muhafazakâr denetim dışarıdaki enerjinin aynı
yayıcıya ait olduğunu iddia etmez. Başlangıç BPSK kümesinde 5/6 ret,
1/6 kaçan kapsam sonucu kaldı: bant kabulü hâlâ başarısızdır. Aralık
kanıtı yetersizken ürüne geçiş yapılmaz. Daha uzun gözlem ve ayrı temiz
emisyon referansı ile tam kuyruk belirsizliği giderilmelidir.

26 temel/regresyon testi, alan bağımsız dış-emisyon kontrolü eklendikten
sonra 27/27 geçti. Bunlar algoritma doğruluğunun tüm kapsamını kanıtlamaz.

## Ürüne geçiş kapıları

1. Desteklenen her ailede en az %80 karar kapsamı ve verilen kararlarda
   en az %90 doğruluk; Belirsiz ve yanlışlar tüm paydalarıyla saklanır.
2. Gürültü, CW, chirp, çoklu yayın, aralık dışı, sıra kesintisi ve kırpılma
   olumsuz kontrolleri. Dijital periyodik dizinin analogla aynı I/Q'yu
   oluşturabildiği durumlar genel kesin sınıflandırma iddiasını engeller.
3. Taşıyıcı uygulanabilirliği ile çizgi adayını ayır; CW/AM frekans hatası,
   bant sınırlı sayısal OBW ve temiz I/Q güç referansı ayrı ölçülür. Önceki
   yol haritası hata hedefleri korunur; yalnız geçerli sonuçlar seçilmez.
4. Yeni yöntem/profil/kayıt sürümü ve kaynak hash bağı, canlı olay sahipliği,
   iptal, eski kayıt tekrar üretimi, paket kontrolü. Eski F5 hashleri güncellenmez.
5. Python/host C/ARM eşdeğerliği, süre ve bellek; çalışan hizmet/imaj kimliği
   ile fiziksel ürün kabulü. Bu aday için RTL/ARM uygulaması henüz yoktur.
6. Yeni kör RF örnekleri ve referans cihazla kalibrasyon. dBm kalibrasyon
   olmadan açılmaz. Tüm kapılar geçmeden parametre çıkarımı tamamlandı denmez.

Kaynaklar: [ITU-R SM.443-4](https://www.itu.int/rec/R-REC-SM.443-4-200702-I/en),
[moment tabanlı sınıflandırma araştırması](https://pubs.gnuradio.org/index.php/grcon/article/download/7/6/).
Bu kaynaklar seçilen adayın performansını kanıtlamaz.
