from pathlib import Path
import sys,json
root=Path.cwd();sys.path.insert(0,str(root))
from scripts import verify_st06_wideband_c as c, verify_st06_wideband_stream as s
clone=root/'build/p0/st06-hybrid-validation'
for name,module in [('corpus',c),('stream',s)]:
 module.ROOT=clone
 report=module.evaluate()
 (clone/(name+'.json')).write_bytes((json.dumps(report,indent=2)+'\n').encode())
 print(name,report['status'],flush=True)
 if report['status']!='passed':raise SystemExit(1)
