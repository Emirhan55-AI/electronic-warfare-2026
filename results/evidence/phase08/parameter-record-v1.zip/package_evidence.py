import hashlib
import json
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from app.operator_console.measurement_record import json_bytes, runtime_binding, replay_measurement

OUT = Path(__file__).resolve().parent
DEST = ROOT / 'results/evidence/phase08/parameter-record-v1.json'
sample = json.loads((OUT / 'sample-summary.json').read_text(encoding='utf-8'))
sample_path = OUT / sample['archive']
replay_measurement(sample_path, expected_sha256=sample['sha256'])
binding = runtime_binding()
suite = ET.parse(OUT / 'tests.xml').getroot().find('testsuite')
failures = [f"{case.attrib['classname']}.{case.attrib['name']}"
            for case in suite.findall('testcase') if case.find('failure') is not None]
assert int(suite.attrib['tests']) == 135 and int(suite.attrib['failures']) == 1
assert failures == ['tests.test_architecture_boundaries.ArchitectureBoundaryTests.test_operator_console_keeps_large_responsibilities_split']
qml = 'app/operator_console/qml/Main.qml'
original = subprocess.check_output(['git', 'show', 'HEAD:' + qml], cwd=ROOT)
current = (ROOT / qml).read_bytes()
# Git's checkout newline policy is ignored only for this unchanged-text check.
assert original.decode('utf-8').splitlines() == current.decode('utf-8').splitlines()
paths = set(binding['sources_sha256']) | {
    'scripts/verify_parameter_record.py', 'scripts/verify_phase04f5_product_integration.py',
    'tests/test_measurement_record.py', 'tests/test_live_ed_view_model.py',
    'tests/test_live_ed_session.py', 'tests/test_phase04f5_product_profile.py',
    'tests/test_app_f_quick_product.py', 'tests/test_operator_product_boundary.py',
    'tests/test_repository_contract.py', 'tests/test_architecture_boundaries.py',
    'config/app/product-package.json', 'app/operator_console/pysidedeploy.spec',
    'scripts/verify_phase00.py', 'profiles/phase04f5/operation-default.json', qml,
}
entries = {f'sources/{name}': (ROOT / name).read_bytes() for name in sorted(paths)}
for name in ['tests.xml', 'tests.txt', 'sample-summary.json', 'f5-current-integration.json', 'cli-replay.json', 'package_evidence.py']:
    entries[name] = (OUT / name).read_bytes()
entries['sample-record.zip'] = sample_path.read_bytes()
archive = DEST.with_suffix('.zip')
assert not DEST.exists() and not archive.exists(), 'Existing evidence must not be replaced'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as target:
    for name, data in entries.items():
        target.writestr(name, data)
report = {
    'schema': 'parameter-record-acceptance-v1', 'date': '2026-09-07',
    'status': 'record_binding_verified', 'overall_test_suite_status': 'failed',
    'requirements': ['KTR-4.2', 'KTR-4.2-F1'], 'work_item': 'PÇ-00',
    'physical_rf_test': False, 'new_board_test': False, 'accuracy_proven': False,
    'tests': {'total': 135, 'passed': 134, 'failed': 1, 'errors': int(suite.attrib['errors']),
              'failed_tests': failures},
    'open_finding': {'file': qml, 'head_lines': len(original.decode('utf-8').splitlines()),
        'current_lines': len(current.decode('utf-8').splitlines()), 'limit': 2200,
        'unchanged_from_head': True, 'reason': 'Önceden mevcut QML dosya boyutu sınırı aşımı; test gevşetilmedi.'},
    'test_command': 'python -m pytest -q tests/test_measurement_record.py tests/test_live_ed_session.py tests/test_live_ed_view_model.py tests/test_phase04f5_product_profile.py tests/test_app_f_quick_product.py tests/test_operator_product_boundary.py tests/test_repository_contract.py tests/test_architecture_boundaries.py',
    'sample_record_sha256': sample['sha256'], 'sample_replay': 'passed',
    'current_f5_integration': json.loads(entries['f5-current-integration.json'])['status'],
    'archive': archive.name, 'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'entry_sha256': {name: hashlib.sha256(data).hexdigest() for name, data in entries.items()},
    'runtime': binding,
    'limits': [
        'Doğrulama kayıt ve yeniden hesaplama bütünlüğüdür; RF doğruluk kabulü değildir.',
        'Alıcı ayarları oturum yapılandırmasıdır; bağımsız cihaz geri okuması değildir.',
        'Donanım UTC zamanı, çalışan kart kimliği ve kalibrasyon bilinmiyor kalır.',
        'Kayıtlar yerel uygulama veri dizininde birikir; toplam disk kotası uygulanmadı.',
        'ST-06, saha doğruluğu, dBm ve ARM taşıma kapıları açıktır.',
    ],
}
DEST.write_bytes(json_bytes(report))
print(json.dumps({'status': report['status'], 'passed': 134, 'failed': 1, 'archive_bytes': archive.stat().st_size}))
