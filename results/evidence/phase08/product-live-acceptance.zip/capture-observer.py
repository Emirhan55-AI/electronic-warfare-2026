"""Local physical acceptance observer; uses the unmodified real RX session."""

from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
import threading
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from PySide6.QtCore import QTimer

from app.operator_console.live_ed import LiveEDSession
from app.operator_console.quick_application import build_quick_application

OUT = ROOT / "build/acceptance/phase08-live-product"
OUT.mkdir(parents=True, exist_ok=True)
lock = threading.Lock()
counter = len(tuple(OUT.glob("run-*.json")))


class ObservedSession(LiveEDSession):
    def run(self, snapshot_handler=None):
        global counter
        with lock:
            counter += 1
            index = counter
        snapshots = []
        started = time.perf_counter()
        report = {
            "recorded_at": datetime.now(timezone.utc).isoformat(),
            "configuration": asdict(self.configuration),
            "backend": "real HackRFContinuousRX and TCPClientIQTransport",
            "transmit_enabled": False,
            "ui_triggered": True,
        }

        def observe(snapshot):
            snapshots.append({
                "sequence_number": snapshot.sequence_number,
                "iq_sha256": hashlib.sha256(snapshot.output_frame.payload).hexdigest(),
                "response": asdict(snapshot.response),
            })
            if snapshot_handler:
                snapshot_handler(snapshot)

        try:
            result = super().run(observe)
            report["status"] = "passed"
            report["result"] = asdict(result)
            return result
        except Exception as exc:
            report["status"] = "failed"
            report["error_code"] = getattr(exc, "code", type(exc).__name__)
            report["error"] = str(exc)
            raise
        finally:
            report["elapsed_seconds"] = time.perf_counter() - started
            report["snapshots"] = snapshots
            (OUT / f"run-{index:02d}.json").write_text(
                json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
            )


app, engine, view_model = build_quick_application([sys.argv[0]])
view_model._live_session_factory = ObservedSession
last_state = None


def save_ui_state():
    global last_state
    current = (view_model.busy, view_model.frameIndex, view_model.sourceState)
    if current == last_state:
        return
    last_state = current
    payload = {
        "source_state": view_model.sourceState,
        "source_ready": view_model.sourceReady,
        "busy": view_model.busy,
        "frame_index": view_model.frameIndex,
        "frame_count": view_model.frameCount,
        "status": view_model.statusMessage,
        "error": view_model.errorMessage,
        "detection_count": len(view_model.detections),
        "detections": view_model.detections,
        "spectrum_points": len(view_model.spectrumValues),
        "pipeline": view_model.pipelineBlocks,
    }
    (OUT / "ui-state.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )


view_model.stateChanged.connect(save_ui_state)
save_ui_state()
sys.exit(app.exec())
