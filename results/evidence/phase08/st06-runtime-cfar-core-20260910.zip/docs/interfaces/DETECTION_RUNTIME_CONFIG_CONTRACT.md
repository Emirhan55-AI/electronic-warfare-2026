# Çalışma sırasında tespit yapılandırması

10 Eylül 2026 · ST-06 · KTR-4.1 / KTR-4.1-OPS-B0

## Durum ve sınır

Kullanıcı, mevcut profil korunarak FFT, pencere ve tespit ayarlarının gerçek
FPGA/ARM yoluna bağlanmasını istedi. Bu çalışma ST-06 içindedir. İlk parça
CFAR çekirdeğindeki isteğe bağlı katsayı girişidir. AXI kontrol bağlantısı,
Linux sürücüsü, ARM hizmeti ve arayüz uygulama/geri okuma zinciri henüz yoktur.
FFT 4096 ve Hann değişmemiştir. Arayüzde yeni yetenek çalışıyor diye gösterilmez.

`axis_p0_os_cfar` modülünde `RUNTIME_CONFIG=0` varsayılandır. Mevcut üst modül
bu değeri kullanır ve karar çarpımlarında özgün sabitleri korur. `=1` seçilirse
normal ve zayıf Q32 katsayıları aşağıdaki el sıkışmasıyla uygulanabilir.

## Çekirdek bağlantısı

| Sinyal | Anlamı |
|---|---|
| `config_valid`, `config_ready` | Aynı saat kenarında 1 ise istek alınır |
| `config_alpha_q32[35:0]` | Normal güç eşik katsayısı |
| `config_weak_alpha_q32[33:0]` | Zayıf aday güç eşik katsayısı |
| `config_applied` | Geçerli istek uygulandı; bir çevrimlik darbe |
| `config_rejected` | Geçersiz istek reddedildi; etkin profil korunur |
| `active_alpha_q32`, `active_weak_alpha_q32` | Çekirdeğin etkin katsayıları |

İstek yalnız sıfırlama bitmişken, ilk güç hücresi henüz alınmamışken ve giriş
geçerli değilken kabul edilir. Veri ile ayar çakışırsa veri önceliklidir.
Toplama, hesaplama, çıktı ve yeniden eşleme boyunca ayar alınmaz. Bekleme
sırasında isteği tutmak çağıranın sorumluluğudur; çekirdek meşgulken tek
çevrimlik istek uygulanmış sayılmaz. Üst seviye kontrol, I/Q kabulünü durdurup
önceki pencere/FFT/DMA ve ARM kuyruklarını boşaltmadan ayar uygulamamalıdır.
CFAR'ın boş olması bütün DSP zincirinin boş olduğu anlamına gelmez.

Katsayı aralıkları mevcut çarpan genişliğidir: normal `[1,16)`, zayıf `[1,4)`;
zayıf katsayı normalden büyük olamaz. Bu aralıklar RF doğruluk kabulü veya
operatöre açılacak önerilen aralıklar değildir. Reset özgün katsayıları
`36851433755` ve `17098572778` değerlerine getirir.

ARM zayıf olay güç/eşik raporu hâlen özgün katsayıya bağlıdır. Yeni değerler
üründe etkinleştirilmeden önce ARM tarafındaki hesap ve kayıt aynı etkin
profil kimliğine bağlanmalıdır; yalnız PL portunu açmak yeterli değildir.

## Doğrulama ve sonraki kapılar

`tests/test_cfar_runtime_config.py` tamsayı modeliyle dört profil/çerçevede
16.384 kelimeyi karşılaştırır. Geçersiz katsayılar, etkin değer geri okuma,
ilk örnekle çakışma, kare ortası istek, reset ve çıktı geri basıncı denetlenir.
`scripts/check_st06_weak_power_rtl.py` varsayılan yolun 49.152 kelimelik
referans karşılaştırmasını ve mevcut bozuk çerçeve kontrollerini yürütür.

Yeni RTL değişikliği nedeniyle önceki `st06-weak-power-20260910.json`
yerleştirme kanıtının kaynak hash'leri artık çalışma ağacıyla eşleşmez.
Önceki kayıt korunur; yeni çekirdeğin yerleştirme/zamanlama ve fiziksel
kanıtı olarak kullanılamaz. Kontrol zinciri, değişken FFT/pencere, güç
normalizasyonu, tam ürün regresyonu ve fiziksel doğrulama açık işlerdir.

Kart erişiminde 192.168.7.2 adresinde SSH ve 47007 portları açık görüldü.
COM6 ZedBoard giriş ekranını gösterdi. SSH anahtarı önceki kayıtla eşleşmedi;
seri konsol oturumu açılmadığı için çalışan hizmet/imaj kimliği doğrulanamadı.
Anahtar denetimi kaldırılmadı, karta imaj yüklenmedi.
